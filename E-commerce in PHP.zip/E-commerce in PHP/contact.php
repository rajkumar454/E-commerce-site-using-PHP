<?php
include('includes\header.php');
?>
<style type="text/css">
.profile{
background:#F3F2EF;
}
</style>

		<div class="profile">
			<div class="container">
				<div class="contact-form">
						<div class="col-md-6 col-xs-12 contact-grid" style="height:100%; padding-top:50px;" >
						<h3>Leave us the message</h3>
						<form>
							<p class="your-para"></p><h5>Your Name:</h5><p></p>
							<input type="text" value="" onfocus="this.value=&#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value =&#39;&#39;;}">
							<p class="your-para"></p><h5>Your Mail:</h5><p></p>
							<input type="text" value="" onfocus="this.value=&#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value =&#39;&#39;;}">
							<p class="your-para"></p><h5>Your Phone Number:</h5><p></p>
							<input type="text" value="" onfocus="this.value=&#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value =&#39;&#39;;}">
							<p class="your-para"></p><h5>Your Message:</h5><p></p>
							<textarea class="col-xs-12" cols="50" rows="6" value=" " onfocus="this.value=&#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;&#39;;}"></textarea>
							
							<div class="send" >
								<input type="submit" value="Send"style="margin-top:5px;">
							</div>
						</form>
					</div>
						<div class="col-md-6 col-xs-12 " style="padding-top:50px;">
						<center>
						<h3>Contact Information</h3>
						
						<p class="sed-para">Give us a call, send us an email or a letter - or drop by to have a chat. We are always here to help out in whatever way we can.</p>
						  <div class="f14 lh18">
						  
								<p><strong>Corporate Office</strong></p>			  
							
							<p><strong>Lifestyle International (P). Ltd</strong></p>
								<p>77° Town Centre, Building No 3,<br>
								West Wing, Off HAL Airport Road,<br>
								Yamlur P.O., Bangalore – 560 037.<br>
								India. </p>
								<p><strong>Tel: +91 (80) 4179 6565</strong></p>
												
									</div>
						<div class="more-address"> 
							<div class="address-more">
																<p style="text-align:center;"><a href="mailto:mail@demolink.org">support@lifestyle.com</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
						</center>
					</div>
					
				
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
   
<?php
include('includes\footer.php');

?>	
</body>
</html>