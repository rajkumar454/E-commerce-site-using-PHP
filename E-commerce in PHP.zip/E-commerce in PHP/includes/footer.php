<?php

$footer = '
</body>
<br />
<br />
<br />
<div class="container ">
	<div class="navbar-fixed-bottom">
	<footer>

		<center>
			<p>Copyright © Lifestyle Store. All Rights Reserved | Contact Us: +91 90000 00000</p>
		</center>
	</footer>	
</div>
';

echo $footer;
?>
